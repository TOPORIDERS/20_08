package com.example.nico2008.model;

public class Verifie implements  IVerifie {

        public static final int MAIN_LENGTH = 5
        public static final int WEAK 
        public static final int
        public static final int









    @Override
    public boolean evalueteLength(String password) {
        return false;
    }

    @Override
    public boolean evalueteUpper(String password) {
        return false;
    }
}
