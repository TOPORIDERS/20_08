package com.example.nico2008.model;

public interface IVerifie {
    boolean evalueteLength (String password);

    boolean evalueteUpper  (String password);
}
